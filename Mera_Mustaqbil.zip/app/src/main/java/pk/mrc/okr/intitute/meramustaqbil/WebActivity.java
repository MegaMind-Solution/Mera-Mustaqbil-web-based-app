package pk.mrc.okr.intitute.meramustaqbil;

import android.animation.*;
import android.app.*;
import android.app.AlertDialog;
import android.content.*;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout.OnRefreshListener;
import com.google.android.material.appbar.AppBarLayout;
import de.hdodenhof.circleimageview.*;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.util.*;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;

public class WebActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	
	private Toolbar _toolbar;
	private AppBarLayout _app_bar;
	private CoordinatorLayout _coordinator;
	private DrawerLayout _drawer;
	
	private SwipeRefreshLayout swip;
	private WebView web;
	private LinearLayout _drawer_linear5;
	private LinearLayout _drawer_hdbg;
	private LinearLayout _drawer_linear19;
	private LinearLayout _drawer_fb;
	private LinearLayout _drawer_tiktik;
	private LinearLayout _drawer_wa;
	private LinearLayout _drawer_cnt;
	private LinearLayout _drawer_inf;
	private LinearLayout _drawer_linear20;
	private ImageView _drawer_imageview8;
	private LinearLayout _drawer_linear21;
	private TextView _drawer_textview7;
	private ImageView _drawer_imageview2;
	private TextView _drawer_textview2;
	private CircleImageView _drawer_circleimageview1;
	private TextView _drawer_textview4;
	private ImageView _drawer_imageview5;
	private TextView _drawer_textview5;
	private ImageView _drawer_imageview10;
	private TextView _drawer_textview11;
	private ImageView _drawer_imageview6;
	private TextView _drawer_textview6;
	private TextView _drawer_textview9;
	
	private Intent intent = new Intent();
	private TimerTask time;
	private AlertDialog.Builder dialog;
	private TimerTask t;
	private Intent fb = new Intent();
	private Intent titik = new Intent();
	private Intent cnt = new Intent();
	private Intent wa = new Intent();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.web);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		_app_bar = findViewById(R.id._app_bar);
		_coordinator = findViewById(R.id._coordinator);
		_toolbar = findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		_drawer = findViewById(R.id._drawer);
		ActionBarDrawerToggle _toggle = new ActionBarDrawerToggle(WebActivity.this, _drawer, _toolbar, R.string.app_name, R.string.app_name);
		_drawer.addDrawerListener(_toggle);
		_toggle.syncState();
		
		LinearLayout _nav_view = findViewById(R.id._nav_view);
		
		swip = findViewById(R.id.swip);
		web = findViewById(R.id.web);
		web.getSettings().setJavaScriptEnabled(true);
		web.getSettings().setSupportZoom(true);
		_drawer_linear5 = _nav_view.findViewById(R.id.linear5);
		_drawer_hdbg = _nav_view.findViewById(R.id.hdbg);
		_drawer_linear19 = _nav_view.findViewById(R.id.linear19);
		_drawer_fb = _nav_view.findViewById(R.id.fb);
		_drawer_tiktik = _nav_view.findViewById(R.id.tiktik);
		_drawer_wa = _nav_view.findViewById(R.id.wa);
		_drawer_cnt = _nav_view.findViewById(R.id.cnt);
		_drawer_inf = _nav_view.findViewById(R.id.inf);
		_drawer_linear20 = _nav_view.findViewById(R.id.linear20);
		_drawer_imageview8 = _nav_view.findViewById(R.id.imageview8);
		_drawer_linear21 = _nav_view.findViewById(R.id.linear21);
		_drawer_textview7 = _nav_view.findViewById(R.id.textview7);
		_drawer_imageview2 = _nav_view.findViewById(R.id.imageview2);
		_drawer_textview2 = _nav_view.findViewById(R.id.textview2);
		_drawer_circleimageview1 = _nav_view.findViewById(R.id.circleimageview1);
		_drawer_textview4 = _nav_view.findViewById(R.id.textview4);
		_drawer_imageview5 = _nav_view.findViewById(R.id.imageview5);
		_drawer_textview5 = _nav_view.findViewById(R.id.textview5);
		_drawer_imageview10 = _nav_view.findViewById(R.id.imageview10);
		_drawer_textview11 = _nav_view.findViewById(R.id.textview11);
		_drawer_imageview6 = _nav_view.findViewById(R.id.imageview6);
		_drawer_textview6 = _nav_view.findViewById(R.id.textview6);
		_drawer_textview9 = _nav_view.findViewById(R.id.textview9);
		dialog = new AlertDialog.Builder(this);
		
		web.setWebViewClient(new WebViewClient() {
			@Override
			public void onPageStarted(WebView _param1, String _param2, Bitmap _param3) {
				final String _url = _param2;
				
				super.onPageStarted(_param1, _param2, _param3);
			}
			
			@Override
			public void onPageFinished(WebView _param1, String _param2) {
				final String _url = _param2;
				
				super.onPageFinished(_param1, _param2);
			}
		});
		
		_drawer_fb.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				SketchwareUtil.CustomToast(getApplicationContext(), "Follow On FaceBook", 0xFFFFFFFF, 18, 0x501A237E, 25, SketchwareUtil.BOTTOM);
				return true;
			}
		});
		
		_drawer_fb.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				fb.setAction(Intent.ACTION_VIEW);
				fb.setData(Uri.parse("https://web.facebook.com/M.Ramzan1318"));
				startActivity(fb);
			}
		});
		
		_drawer_tiktik.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				SketchwareUtil.CustomToast(getApplicationContext(), "Follow On TikTok", 0xFFFFFFFF, 18, 0x501A237E, 25, SketchwareUtil.BOTTOM);
				return true;
			}
		});
		
		_drawer_tiktik.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				titik.setAction(Intent.ACTION_VIEW);
				titik.setData(Uri.parse("https://tiktok.com/mr.13181"));
				startActivity(titik);
			}
		});
		
		_drawer_wa.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				SketchwareUtil.CustomToast(getApplicationContext(), "Contact On WhatsApp", 0xFFFFFFFF, 18, 0x501A237E, 25, SketchwareUtil.BOTTOM);
				return true;
			}
		});
		
		_drawer_wa.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				wa.setAction(Intent.ACTION_VIEW);
				wa.setData(Uri.parse("https://api.whatsapp.com/send?phone=".concat("+92-308-9548888&text=Hello,")));
				startActivity(wa);
			}
		});
		
		_drawer_cnt.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				SketchwareUtil.CustomToast(getApplicationContext(), "Contact Us", 0xFFFFFFFF, 18, 0x501A237E, 25, SketchwareUtil.BOTTOM);
				return true;
			}
		});
		
		_drawer_cnt.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				cnt.setAction(Intent.ACTION_DIAL);
				cnt.setData(Uri.parse("tel:".concat("+92-308-9548888")));
				startActivity(cnt);
			}
		});
		
		_drawer_inf.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				SketchwareUtil.CustomToast(getApplicationContext(), "About Developer", 0xFFFFFFFF, 18, 0x501A237E, 25, SketchwareUtil.BOTTOM);
				return true;
			}
		});
		
		_drawer_inf.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.setClass(getApplicationContext(), InfoActivity.class);
				startActivity(intent);
			}
		});
	}
	
	private void initializeLogic() {
		web.loadUrl("github.com");
		swip.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
			@Override
			public void onRefresh() {
				web.loadUrl("github.com");
				time = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								swip.setRefreshing(false);
							}
						});
					}
				};
				_timer.schedule(time, (int)(1500));
			}
		});
	}
	
	@Override
	public void onBackPressed() {
		if (_drawer.isDrawerOpen(GravityCompat.START)) {
			_drawer.closeDrawer(GravityCompat.START);
		} else {
			super.onBackPressed();
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}