package pk.mrc.okr.intitute.meramustaqbil;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.Intent;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;

public class InfoActivity extends AppCompatActivity {
	
	private ScrollView hi;
	private LinearLayout info_dev;
	private CardView cardviewimg;
	private LinearLayout name_bg;
	private TextView description;
	private LinearLayout border;
	private TextView icons_description;
	private LinearLayout social_lay;
	private LinearLayout border_2;
	private LinearLayout powered;
	private ImageView infoimg;
	private TextView name;
	private LinearLayout icons_tray;
	private LinearLayout gmail;
	private LinearLayout insta;
	private LinearLayout fb;
	private LinearLayout whats;
	private ImageView gmail_icon;
	private ImageView Instagram;
	private ImageView Facebook;
	private ImageView GitHub;
	private ImageView mrc_branding;
	private LinearLayout border_3;
	private ImageView mrd_branding;
	private LinearLayout linear3;
	private TextView textview2;
	
	private Intent tel = new Intent();
	private Intent fcb = new Intent();
	private Intent inst = new Intent();
	private Intent git = new Intent();
	private Intent release = new Intent();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.info);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		hi = findViewById(R.id.hi);
		info_dev = findViewById(R.id.info_dev);
		cardviewimg = findViewById(R.id.cardviewimg);
		name_bg = findViewById(R.id.name_bg);
		description = findViewById(R.id.description);
		border = findViewById(R.id.border);
		icons_description = findViewById(R.id.icons_description);
		social_lay = findViewById(R.id.social_lay);
		border_2 = findViewById(R.id.border_2);
		powered = findViewById(R.id.powered);
		infoimg = findViewById(R.id.infoimg);
		name = findViewById(R.id.name);
		icons_tray = findViewById(R.id.icons_tray);
		gmail = findViewById(R.id.gmail);
		insta = findViewById(R.id.insta);
		fb = findViewById(R.id.fb);
		whats = findViewById(R.id.whats);
		gmail_icon = findViewById(R.id.gmail_icon);
		Instagram = findViewById(R.id.Instagram);
		Facebook = findViewById(R.id.Facebook);
		GitHub = findViewById(R.id.GitHub);
		mrc_branding = findViewById(R.id.mrc_branding);
		border_3 = findViewById(R.id.border_3);
		mrd_branding = findViewById(R.id.mrd_branding);
		linear3 = findViewById(R.id.linear3);
		textview2 = findViewById(R.id.textview2);
		
		//OnTouch
		cardviewimg.setOnTouchListener(new View.OnTouchListener(){
				@Override
				public boolean onTouch(View v, MotionEvent event){
						int ev = event.getAction();
						switch (ev) {
								case MotionEvent.ACTION_DOWN:
								
								 SketchwareUtil.CustomToast(getApplicationContext(), "Picture Of M.Saim", 0xFFFFFFFF, 18, 0x501A237E, 25, SketchwareUtil.BOTTOM);
								
								break;
								case MotionEvent.ACTION_UP:
								
								 
								
								break;
						} return true;
				}
		});
		
		//OnTouch
		description.setOnTouchListener(new View.OnTouchListener(){
				@Override
				public boolean onTouch(View v, MotionEvent event){
						int ev = event.getAction();
						switch (ev) {
								case MotionEvent.ACTION_DOWN:
								
								 SketchwareUtil.CustomToast(getApplicationContext(), "Description?", 0xFFFFFFFF, 18, 0x501A237E, 25, SketchwareUtil.BOTTOM);
								
								break;
								case MotionEvent.ACTION_UP:
								
								 
								
								break;
						} return true;
				}
		});
		
		//OnTouch
		gmail.setOnTouchListener(new View.OnTouchListener(){
				@Override
				public boolean onTouch(View v, MotionEvent event){
						int ev = event.getAction();
						switch (ev) {
								case MotionEvent.ACTION_DOWN:
								
								 SketchwareUtil.CustomToast(getApplicationContext(), "Report Me Any Issues Errors Or Bug", 0xFFFFFFFF, 18, 0x501A237E, 25, SketchwareUtil.BOTTOM);
					tel.setAction(Intent.ACTION_VIEW);
					tel.setData(Uri.parse("mailto:".concat("thirdpartylocal@gmail.com")));
					startActivity(tel);
								
								break;
								case MotionEvent.ACTION_UP:
								
								 
								
								break;
						} return true;
				}
		});
		
		//OnTouch
		insta.setOnTouchListener(new View.OnTouchListener(){
				@Override
				public boolean onTouch(View v, MotionEvent event){
						int ev = event.getAction();
						switch (ev) {
								case MotionEvent.ACTION_DOWN:
								
								 SketchwareUtil.CustomToast(getApplicationContext(), "Follow Me On Instagram", 0xFFFFFFFF, 18, 0x501A237E, 25, SketchwareUtil.BOTTOM);
					inst.setAction(Intent.ACTION_VIEW);
					inst.setData(Uri.parse("https://www.instagram.com/rm4814691"));
					startActivity(inst);
								
								break;
								case MotionEvent.ACTION_UP:
								
								 
								
								break;
						} return true;
				}
		});
		
		//OnTouch
		fb.setOnTouchListener(new View.OnTouchListener(){
				@Override
				public boolean onTouch(View v, MotionEvent event){
						int ev = event.getAction();
						switch (ev) {
								case MotionEvent.ACTION_DOWN:
								
								 SketchwareUtil.CustomToast(getApplicationContext(), "Follow Me On FaceBook ", 0xFFFFFFFF, 18, 0x501A237E, 25, SketchwareUtil.BOTTOM);
					fcb.setAction(Intent.ACTION_VIEW);
					fcb.setData(Uri.parse("https://web.facebook.com/M.Ramzan1318"));
					startActivity(fcb);
								
								break;
								case MotionEvent.ACTION_UP:
								
								 
								
								break;
						} return true;
				}
		});
		
		//OnTouch
		whats.setOnTouchListener(new View.OnTouchListener(){
				@Override
				public boolean onTouch(View v, MotionEvent event){
						int ev = event.getAction();
						switch (ev) {
								case MotionEvent.ACTION_DOWN:
								
								 SketchwareUtil.CustomToast(getApplicationContext(), "Follow Me On GitHub To Get Latest Updates", 0xFFFFFFFF, 18, 0x501A237E, 25, SketchwareUtil.BOTTOM);
					git.setAction(Intent.ACTION_VIEW);
					git.setData(Uri.parse("https://github.com/MegaMind-Solution"));
					startActivity(git);
								
								break;
								case MotionEvent.ACTION_UP:
								
								 
								
								break;
						} return true;
				}
		});
		
		//OnTouch
		mrc_branding.setOnTouchListener(new View.OnTouchListener(){
				@Override
				public boolean onTouch(View v, MotionEvent event){
						int ev = event.getAction();
						switch (ev) {
								case MotionEvent.ACTION_DOWN:
								
								 SketchwareUtil.CustomToast(getApplicationContext(), "This App Is Powered By MicroResearch Corpration", 0xFFFFFFFF, 18, 0x501A237E, 25, SketchwareUtil.BOTTOM);
								
								break;
								case MotionEvent.ACTION_UP:
								
								 
								
								break;
						} return true;
				}
		});
		
		//OnTouch
		mrd_branding.setOnTouchListener(new View.OnTouchListener(){
				@Override
				public boolean onTouch(View v, MotionEvent event){
						int ev = event.getAction();
						switch (ev) {
								case MotionEvent.ACTION_DOWN:
								
								 SketchwareUtil.CustomToast(getApplicationContext(), "This App Is UI & UX Design By MindRise Designs", 0xFFFFFFFF, 18, 0x501A237E, 25, SketchwareUtil.BOTTOM);
								
								break;
								case MotionEvent.ACTION_UP:
								
								 
								
								break;
						} return true;
				}
		});
		
		//OnTouch
		textview2.setOnTouchListener(new View.OnTouchListener(){
				@Override
				public boolean onTouch(View v, MotionEvent event){
						int ev = event.getAction();
						switch (ev) {
								case MotionEvent.ACTION_DOWN:
								
								 SketchwareUtil.CustomToast(getApplicationContext(), "About Developer", 0xFFFFFFFF, 18, 0x501A237E, 25, SketchwareUtil.BOTTOM);
					release.setAction(Intent.ACTION_VIEW);
					release.setData(Uri.parse("https://github.com/MegaMind-Solution/Mera-Mustaqbil-WebBased-App/releases/"));
					startActivity(release);
								
								break;
								case MotionEvent.ACTION_UP:
								
								 
								
								break;
						} return true;
				}
		});
	}
	
	private void initializeLogic() {
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}